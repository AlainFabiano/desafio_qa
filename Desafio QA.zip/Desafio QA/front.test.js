describe('Frontend', () => {
    beforeAll(async () => {
        await page.goto("http://localhost")
    })

    test('Should show list', async () => {
        await expect(page.title()).resolves.toBe("ChallengeGuararapes")
    })
    
    test('Busca Matéria-Prima', () => {
      let materiaPrima = new materiaPrima()
           expect(materiaPrima).toBe("linha")
    })
    
      
    test('Busca Nome', () => {
      let Nome = new Nome()
           expect(Nome).toBe("bermuda")
    })
    
      
    test('Busca Estoque', () => {
      let Estoque = new Estoque()
           expect(Estoque).toBe("50")
    })
    
    const materialHttp = [
    'tecido',
    'linha',
    'tinta branca',
    'tinta preta'
]
test('O material está na lista' ,()=>{
    expect(verbosHttp).toContain('linha')
})
      
   })
