const Axios = require("axios");

test('api should list materials', async () => {
    let response = await Axios.get("http://localhost:8080/material");

    expect(response.status).toBe(200);
});

const Axios = require("axios");

test('api should list materials', async () => {
    let response = await Axios.get("http://localhost:8080/material");

    expect(response.status).toBe("tinta");
});

const Axios = require("axios");

test('api should list nome', async () => {
    let response = await Axios.get("http://localhost:8080/nome");

    expect(response.status).toBe("calça");
});

const Axios = require("axios");

test('api should list estoque', async () => {
    let response = await Axios.get("http://localhost:8080/estoque");

    expect(response.status).toBe(5);
});

test('Estoque maior que o informado',
	    () => {
	        expect(estoque.getQuantidade()).toBeGreaterThan(estoque.getQuantidade(10))
	})
	
	function conectaBancoDeDados(){
    throw new Error('Não foi possível conectar ao banco de dados')
}

test('conexão com o banco de dados falha como esperado' ,()=>{
    expect(conectaBancoDeDados).toThrow(Error)
})